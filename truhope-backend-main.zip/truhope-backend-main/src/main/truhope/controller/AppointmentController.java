package com.truhope.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RestController;

import com.truhope.model.Appointment;
import com.truhope.repository.AppointmentRepository;
import com.truhope.service.AppointmentService;

@RestController
@CrossOrigin(origins = "http://localhost:3000/")
public class AppointmentController {

	@Autowired
	private AppointmentService appiAppointmentService;
	
	@PostMapping("/BookAppointment")
	public Appointment CreateAppointment(@RequestBody Appointment a)
	{
		return appiAppointmentService.saveAppointment(a);
	}

}
