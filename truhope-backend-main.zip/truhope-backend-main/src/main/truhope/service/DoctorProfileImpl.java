package com.truhope.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truhope.model.DoctorProfile;
import com.truhope.repository.DoctorProfileRepository;

@Service
public class DoctorProfileImpl implements DoctorProfileService {
	
	@Autowired
	DoctorProfileRepository doctorProfileRepository;

	public DoctorProfile fetchByUsername(String username) {
		DoctorProfile doctorProfile = doctorProfileRepository.findByUsername(username);
		
		return doctorProfile;
	}
	
	public DoctorProfile addDoctorProfile(DoctorProfile doctorProfile) {
		
		return doctorProfileRepository.save(doctorProfile);
	}
	
	public List<DoctorProfile> findAllDoctors() {
		
		return doctorProfileRepository.findAll();
	}
}
