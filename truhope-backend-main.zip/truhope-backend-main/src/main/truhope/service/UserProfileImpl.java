
package com.truhope.service;

import com.truhope.model.DoctorProfile;
import com.truhope.model.UserProfile;
import com.truhope.repository.DoctorProfileRepository;
import com.truhope.repository.UserProfileRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.stereotype.Service;

@Service
public class UserProfileImpl implements UserProfileService {

    @Autowired
    private UserProfileRepository userProfileRepository;

    @Autowired
    private DoctorProfileRepository doctorProfileRepository;
    
    @Override
    public UserProfile getUserProfile(String username) throws UsernameNotFoundException {
        return userProfileRepository.findByUsername(username);
    }

    @Override
    public UserProfile addUserProfile(UserProfile userProfile) {
        return userProfileRepository.save(userProfile);
    }
    
  
}
