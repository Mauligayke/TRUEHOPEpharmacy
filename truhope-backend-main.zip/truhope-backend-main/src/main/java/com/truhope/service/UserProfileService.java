package com.truhope.service;

import com.truhope.model.DoctorProfile;
import com.truhope.model.UserProfile;

public interface UserProfileService {

    UserProfile getUserProfile(String username);

    UserProfile addUserProfile(UserProfile userProfile);
    
}
