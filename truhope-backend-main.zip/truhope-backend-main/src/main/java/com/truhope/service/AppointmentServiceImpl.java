package com.truhope.service;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truhope.model.Appointment;
import com.truhope.repository.AppointmentRepository;

@Service
public class AppointmentServiceImpl implements AppointmentService {
	
	@Autowired
	private AppointmentRepository appointmentRepository;
	public Appointment saveAppointment(Appointment appointment)
	{
		return appointmentRepository.save(appointment);
	}
}
