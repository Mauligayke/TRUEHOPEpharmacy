package com.truhope.service;

import com.truhope.model.Appointment;

public interface AppointmentService {
      Appointment saveAppointment(Appointment appointment);
}
