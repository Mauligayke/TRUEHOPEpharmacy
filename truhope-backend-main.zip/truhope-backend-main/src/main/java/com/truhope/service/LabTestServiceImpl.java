package com.truhope.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.truhope.model.LabTest;
import com.truhope.repository.LabTestRepository;

@Service
public class LabTestServiceImpl implements LabTestService {
	
	@Autowired
	LabTestRepository labTestRepo;
	
	public LabTest saveTest(LabTest labtest) {
		
		return labTestRepo.save(labtest);
	}
   public List<LabTest> fetchAllTest(){
    	
	   return labTestRepo.findAll();
    }
}
