package com.truhope.service;

import java.util.List;

import com.truhope.model.Product;

public interface ProductService {

	List<Product> fetchAllProducts(String category);
	Product fetchProductById(int id);
	Product saveProduct(Product product);
}
