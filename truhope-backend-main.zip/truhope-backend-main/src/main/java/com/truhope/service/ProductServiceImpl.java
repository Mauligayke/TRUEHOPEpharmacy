package com.truhope.service;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.web.bind.annotation.PostMapping;

import com.truhope.model.Product;
import com.truhope.repository.ProductRepository;

@Service
public class ProductServiceImpl implements ProductService {

	@Autowired
	ProductRepository productRepo;
	
	public List<Product> fetchAllProducts(String category){
		
		List<Product> productList = productRepo.findAllByCategory(category);
		
		
		return productList;
	}
	
	public Product fetchProductById(int id) {
		Product product = productRepo.findByProductId(id);
		
		return product;
	}
	
	
	public Product saveProduct(Product product) {
		
		return productRepo.save(product);
	}
}
