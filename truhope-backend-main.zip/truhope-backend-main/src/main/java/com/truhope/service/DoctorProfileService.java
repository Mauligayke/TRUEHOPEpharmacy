package com.truhope.service;

import java.util.List;

import com.truhope.model.DoctorProfile;

public interface DoctorProfileService {
	
	DoctorProfile fetchByUsername(String username);
	DoctorProfile addDoctorProfile(DoctorProfile doctorProfile);
	List<DoctorProfile> findAllDoctors();
}
