package com.truhope.service;

import java.util.List;

import com.truhope.model.LabTest;

public interface LabTestService {
    LabTest saveTest(LabTest labtest);
    List<LabTest> fetchAllTest();
}
