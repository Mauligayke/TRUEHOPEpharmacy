package com.truhope.controller;

import com.truhope.model.UserProfile;
import com.truhope.payload.request.Username;
import com.truhope.service.UserProfileService;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.net.URI;

@RestController
@RequestMapping("/user")
@CrossOrigin(origins = "http://localhost:3000/")
public class UserController {

    @Autowired
    private UserProfileService userProfileService;

    @PostMapping("/profile")
    private ResponseEntity<UserProfile> getUserprofile(@RequestBody Username username) {
        UserProfile userProfile = null;
        try {
            userProfile = userProfileService.getUserProfile(username.getUsername());
        } catch (UsernameNotFoundException notFound) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().body(userProfile);
    }

    @PostMapping("/add/profile")
    private ResponseEntity<UserProfile> adduserProfile(@RequestBody UserProfile userProfile) {
        
        return ResponseEntity.ok().body(userProfileService.addUserProfile(userProfile));
    }
}
