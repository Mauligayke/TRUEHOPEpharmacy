package com.truhope.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.truhope.model.Product;
import com.truhope.service.ProductService;

@RestController
@RequestMapping("/products")
@CrossOrigin("http://localhost:3000/")
public class ProductController {
	
	@Autowired
	ProductService productService;
	
	@GetMapping("/findAllProducts")
	public List<Product> findAllProducts(@RequestParam String category) {
		List<Product> productList = productService.fetchAllProducts(category);
		
		return productList;
	}
	
	@GetMapping("/{id}")
	public ResponseEntity<Product> findProductById(@PathVariable int id) {
		
		Product product = productService.fetchProductById(id);
		return ResponseEntity.ok().body(product);
	}
	
	@PostMapping("/add")
	public ResponseEntity<Product> addProduct(@RequestBody Product product) {
		URI uri = URI.create(ServletUriComponentsBuilder.fromCurrentContextPath().path("/products/add").toUriString());
		
		return ResponseEntity.created(uri).body(productService.saveProduct(product));
	}

}
