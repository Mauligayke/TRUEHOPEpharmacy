package com.truhope.controller;

import java.net.URI;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.security.core.userdetails.UsernameNotFoundException;
import org.springframework.web.bind.annotation.CrossOrigin;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestBody;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import com.truhope.model.DoctorProfile;
import com.truhope.model.UserProfile;
import com.truhope.payload.request.Username;
import com.truhope.service.DoctorProfileService;
import com.truhope.service.UserProfileService;

@RestController
@RequestMapping("/doctor")
@CrossOrigin(origins = "http://localhost:3000/")
public class DoctorProfileController {

	@Autowired
	private DoctorProfileService doctorProfileService;
	
	@PostMapping("/doctorProfile")
    private ResponseEntity<Object> getDoctorProfile(@RequestBody Username username) {
		DoctorProfile doctorProfile = null;
        try {
        	doctorProfile = doctorProfileService.fetchByUsername(username.getUsername());
        } catch (UsernameNotFoundException notFound) {
            return ResponseEntity.notFound().build();
        }
        return ResponseEntity.ok().body(doctorProfile);
    }
	
	@PostMapping("/add/profile")
    private ResponseEntity<DoctorProfile> addDoctorProfile(@RequestBody DoctorProfile doctorProfile) {
		System.out.println("Adding Doctor");
        URI uri = URI.create(ServletUriComponentsBuilder.fromCurrentContextPath().path("/doctor/add/profile").toUriString());
        return ResponseEntity.created(uri).body(doctorProfileService.addDoctorProfile(doctorProfile));
    }
	
	@GetMapping("/allDoctors")
	private List<DoctorProfile> fetchAllDoctors() {
        
		return doctorProfileService.findAllDoctors();
    } 
}
