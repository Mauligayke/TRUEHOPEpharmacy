package com.truhope.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.truhope.model.LabTest;

public interface LabTestRepository extends JpaRepository<LabTest, Integer> {
      LabTest save(LabTest labtest);
      List<LabTest> findAll();
}
