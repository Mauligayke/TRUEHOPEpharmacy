package com.truhope.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;

import com.truhope.model.Product;

public interface ProductRepository extends JpaRepository<Product, Integer> {

	List<Product> findAll();
	
	List<Product> findAllByCategory(String category);
	
	Product findByProductId(int id);
	
	Product save(Product product);
}
