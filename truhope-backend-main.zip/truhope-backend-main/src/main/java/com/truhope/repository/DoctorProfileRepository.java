package com.truhope.repository;

import java.util.List;

import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import com.truhope.model.DoctorProfile;

@Repository
public interface DoctorProfileRepository  extends JpaRepository<DoctorProfile, Integer> {
	DoctorProfile findByUsername(String username);
	DoctorProfile save(DoctorProfile doctorProfile);
	List<DoctorProfile> findAll();
}
