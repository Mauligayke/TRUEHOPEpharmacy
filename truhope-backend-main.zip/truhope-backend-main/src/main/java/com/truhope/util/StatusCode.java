package com.truhope.util;

public class StatusCode {

    public final static int USERNAME_ALREADY_EXIST = 901;
    public final static int ACCESS_TOKEN_EXPIRED = 902;
    public static final int ACCESS_TOKEN_VALID = 903;
}
