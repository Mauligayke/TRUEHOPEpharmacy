package com.truhope.model;

public enum ERole {
  ROLE_USER,
  ROLE_DOCTOR,
  ROLE_ADMIN,
  ROLE_PATIENT
}
